public class Path {
	int vertex;
	Path next; // next_vertex
	
	Path(){
		vertex = 0;
		next = null;
	}
	
	Path(int v) {
		vertex = v;
		next = null;
	}

	Path(int v, Path p) {
		vertex = v;
		next = p;
	}
};