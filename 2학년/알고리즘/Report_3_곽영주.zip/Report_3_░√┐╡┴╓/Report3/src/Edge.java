public class Edge {
	int vertex_1; // ������
	int vertex_2; // ����

	public Edge(int v1, int v2) {
		vertex_1 = v1;
		vertex_2 = v2;
	}
	
	public int getVertex_1() {
		return vertex_1;
	}
	
	public int getVertex_2() {
		return vertex_2;
	}
}
