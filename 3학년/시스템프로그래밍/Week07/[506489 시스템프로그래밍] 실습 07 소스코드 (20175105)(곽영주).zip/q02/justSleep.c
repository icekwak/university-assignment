#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define SEC 5

int main() {
	sleep(SEC);
	return 0;
}
