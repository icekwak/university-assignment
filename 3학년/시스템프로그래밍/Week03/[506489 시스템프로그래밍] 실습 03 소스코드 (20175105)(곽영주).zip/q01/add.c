#include <stdio.h>

void add(int x, int y) {

	printf("Result: %d + %d = %d\n", x, y, x+y);
}
