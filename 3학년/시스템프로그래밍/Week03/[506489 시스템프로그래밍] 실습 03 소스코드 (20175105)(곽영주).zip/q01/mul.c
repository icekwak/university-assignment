#include <stdio.h>

void mul(int x, int y) {
	
	printf("Result: %d * %d = %d\n", x, y, x*y);
}
