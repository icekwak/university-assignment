# About Unity Collaborate

Collaborate is a simple way for teams to save, share, and sync their Unity project.

Please refer to the online documentation [here.](https://docs.unity3d.com/Manual/UnityCollaborate.html)
