﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block
{
    public enum TYPE
    {
        NONE = -1,
        FLOOR = 0,
        HOLE,
        NUM,
    };
};

public class level_control : MonoBehaviour
{
    public struct CreationInfo
    {
        public Block.TYPE block_type;
        public int max_count;
        public int height;
        public int current_count;
    };

    public CreationInfo previous_block;
    public CreationInfo current_block;
    public CreationInfo next_block;

    public int level = 0;

    private void ClearNextBlock(ref CreationInfo block)
    {
        block.block_type = Block.TYPE.FLOOR;
        block.max_count = 15;
        block.height = 0;
        block.current_count = 0;
    }

    public void Initialized()
    {
        ClearNextBlock(ref previous_block);
        ClearNextBlock(ref current_block);
        ClearNextBlock(ref next_block);
    }
    player_control player = null;
    private void UpdateLevel(ref CreationInfo current, CreationInfo previous)
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<player_control>();
        switch (previous.block_type)
        {
            case Block.TYPE.FLOOR:
                current.block_type = Block.TYPE.HOLE;
               
                // 블록 시간대(초)별로 제거
                if (player.timer >= 15 && player.timer < 30) // 15~29
                    current.max_count = Random.Range(1, 3);
                else if (player.timer >= 30 && player.timer < 45) // 30~44
                    current.max_count = Random.Range(2, 4);
                else if (player.timer >= 45 && player.timer < 60) // 45~59
                    current.max_count = Random.Range(2, 4);
                else if (player.timer >= 60 && player.timer < 75) // 60~74
                    current.max_count = Random.Range(1, 3);
                else                                              // 0~14 or 75~
                {
                    if (player.timer >= 75) // 75~이면 timer = 0;
                        player.timer = 0;
                    current.max_count = Random.Range(1, 3);
                }

                current.height = previous.height;
                break;

            case Block.TYPE.HOLE:
                current.block_type = Block.TYPE.FLOOR;
                
                // 블록 시간대(초)별로 생성
                if (player.timer >= 15 && player.timer < 30) // 15~29
                    current.max_count = Random.Range(8, 10);
                else if (player.timer >= 30 && player.timer < 45) // 30~44
                    current.max_count = Random.Range(7, 9);
                else if (player.timer >= 45 && player.timer < 60) // 45~59
                    current.max_count = Random.Range(5, 7);
                else if (player.timer >= 60 && player.timer < 75) // 60~74
                    current.max_count = Random.Range(6, 8);
                else                                              // 0~14 or 75~
                {
                    if (player.timer >= 75) // 75~이면 timer = 0;
                        player.timer = 0;
                    current.max_count = Random.Range(9, 11);
                }
                
                break;
        }
    }

    public void UpdateStatus()
    {
        current_block.current_count++;

        if(current_block.current_count >= current_block.max_count)
        {
            previous_block = current_block;
            current_block = next_block;

            ClearNextBlock(ref next_block);
            UpdateLevel(ref next_block, current_block);
        }
    }
}
