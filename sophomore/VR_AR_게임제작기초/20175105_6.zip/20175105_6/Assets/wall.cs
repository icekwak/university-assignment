﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class wall : MonoBehaviour
{
    public float speed;
    public float height;

    void Start()
    {
        speed = Random.Range(-6.0f, -4.0f); // 속도 -6~-4
        height = Random.Range(-3.0f, 4.0f); // 높이 -3~4
        transform.position += new Vector3(5, height, 0);
        Destroy(gameObject, 6.0f);
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(speed * Time.deltaTime, 0, 0);
    }
}
