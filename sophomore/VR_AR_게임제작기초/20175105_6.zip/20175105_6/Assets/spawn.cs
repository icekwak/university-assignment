﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawn : MonoBehaviour
{
    public GameObject pf_wall;
    public float interval;

    IEnumerator Start()
    {
        while (true)
        {
            interval = Random.Range(1.0f, 2.0f); // 주기 1~2초
            Instantiate(pf_wall, transform.position, transform.rotation);
            yield return new WaitForSeconds(interval);
        }
    }
}
