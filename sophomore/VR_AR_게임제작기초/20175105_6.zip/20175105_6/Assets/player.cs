﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class player : MonoBehaviour
{
    public float jump_power;
    public float timer = 0;

    void Start()
    {
        jump_power = Random.Range(5, 9); // 점프력 5~8
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if (Input.GetButton("Jump")) // 누르고 있는 동안
            GetComponent<Rigidbody>().velocity = new Vector3(0, jump_power, 0);
    }

    void OnCollisionEnter(Collision other)
    {
        SceneManager.LoadScene("main_scene");
    }

    void OnGUI()
    {
        GUI.Label(new Rect(81, Screen.height - 55, 128, 32), "jump : ");
        GUI.Label(new Rect(120, Screen.height - 55, 128, 32), jump_power.ToString());
        GUI.Label(new Rect(81, Screen.height - 40, 128, 32), timer.ToString());
    }
}