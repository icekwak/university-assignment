// using UnityEditor;
// using UnityEditor.SettingsManagement;
// using UnityEngine;
//
// namespace Unity.Cloud.Collaborate.Settings
// {
//     internal class CollabSetting<T> : UserSetting<T>
//     {
//         public CollabSetting(string key, T value, SettingsScope scope = SettingsScope.Project)
//             : base(CollabSettingsManager.instance, key, value, scope)
//         {}
//
//         CollabSetting(UnityEditor.SettingsManagement.Settings settings, string key, T value, SettingsScope scope = SettingsScope.Project)
//             : base(settings, key, value, scope) { }
//     }
// }
