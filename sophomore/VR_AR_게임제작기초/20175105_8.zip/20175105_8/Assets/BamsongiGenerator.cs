﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BamsongiGenerator : MonoBehaviour
{
    public GameObject bamsongi_prefab;
    private int score_result = 0;   // 총 점수
    private int bamsongi_count = 5; // 밤송이 개수
    private GameObject del_bamsongi = null; // 이전 밤송이
    private Vector3 wind; // 풍향 및 풍속 설정
    GUIStyle mystyle = new GUIStyle();

    void Start()
    {
       setWind();
    }

    public void SumScore(int score) // 점수 계산
    {
        score_result += score;
    }

    public void setWind() // 풍향 변경
    {
        float wx = Random.Range(-4.0f, 4.0f);
        float wy = Random.Range(-1.0f, 4.0f);
  
        wind = new Vector3(wx, wy, 0.0f);
    }

    public Vector3 getWind()
    {
        return wind;
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0) && bamsongi_count > 0)
        {
            GameObject bamsongi = Instantiate(bamsongi_prefab) as GameObject;
            Ray screen_ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            Vector3 shooting_ray = screen_ray.direction;
            bamsongi.GetComponent<BamsongiCtrl>().Shoot(shooting_ray * 1000);
            bamsongi_count--;

            // 이전 밤송이 제거
            if (del_bamsongi != null)
                Destroy(del_bamsongi);
            del_bamsongi = bamsongi;
        }
    }

    void OnGUI()
    {
        // 밤송이 개수 = 0이면 재시작
        if (bamsongi_count == 0)
        {
            mystyle.fontSize = 30;
            mystyle.normal.textColor = Color.white;
            GUI.Label(new Rect(270, 150, 120, 50), "Press 'R' to continue", mystyle);
            if (Input.GetKeyDown(KeyCode.R))
                SceneManager.LoadScene("SampleScene");
        }
        GUI.Label(new Rect(10, 0, 120, 20), bamsongi_count.ToString() + " : " + score_result.ToString());
        GUI.Label(new Rect(10, 12, 120, 20), wind.ToString());
    }
}