﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BamsongiCtrl : MonoBehaviour
{
    float timer = 0.0f;
    //bool is_shot = false;
    private GameObject target = null;
    private Vector3 wind;
    private bool check = false;

    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Target");
        wind = GameObject.FindGameObjectWithTag("Player").GetComponent<BamsongiGenerator>().getWind();
    }

    public void Shoot(Vector3 dir)
    {
        GetComponent<Rigidbody>().AddForce(dir);
    }

    // 점수판
    private int Score(float distance)
    {
        if (distance >= 0.0f && distance < 0.4f)
            return 100;
        else if (distance >= 0.4f && distance < 0.8f)
            return 90;
        else if (distance >= 0.8f && distance < 1.2f)
            return 70;
        else if (distance >= 1.2f && distance < 1.6f)
            return 50;
        else if (distance >= 1.6f && distance < 2.0f)
            return 30;
        else
            return 0;
    }

    void Update()
    {
        timer += Time.deltaTime;
        
        GetComponent<Rigidbody>().AddForce(wind, ForceMode.Force);
        
        if(timer >= 2.0f && timer < 2.1f && check == false)
            GameObject.FindGameObjectWithTag("Player").GetComponent<BamsongiGenerator>().setWind();
        
    }

    void OnCollisionEnter(Collision other)
    {
        GetComponent<Rigidbody>().isKinematic = true;
        GetComponent<ParticleSystem>().Play();
        Vector3 collided_position = transform.position;
        float distance = collided_position.x * collided_position.x +
            (collided_position.y - 6.5f) * (collided_position.y - 6.5f);
        distance = Mathf.Sqrt(distance);
        Debug.Log(collided_position);
        Debug.Log(distance);

        if(other.gameObject == target)
        {
            int score = Score(distance); // 점수
            GameObject bg = GameObject.FindGameObjectWithTag("Player");
            bg.GetComponent<BamsongiGenerator>().SumScore(score);

            // target과 충돌 후 풍향 변경
            bg.GetComponent<BamsongiGenerator>().setWind();
            check = true;
        }
    }
}
