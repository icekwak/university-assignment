﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collision_test : MonoBehaviour
{
    public float power = 300.0f;

    void OnCollisionEnter(Collision coll)
    {
        Vector3 launch_direction = new Vector3(0, 1, 1);

        if (coll.gameObject.name == "Cube")
            GetComponent<Rigidbody>().AddForce(launch_direction * power);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
